<?php
define('THINK_PATH', './core/ThinkPHP');
define('RUNTIME_PATH','./temp/');
define('APP_PATH', './core');
define('APP_NAME', 'gxcms');
?>