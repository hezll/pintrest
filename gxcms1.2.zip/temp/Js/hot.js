document.write('<a href="/gxcms/index.php?s=video/search/wd/%E7%83%AD%E9%97%A8%E6%A0%87%E7%AD%BE1">热门标签1</a>');
document.write('<a href="/gxcms/index.php?s=video/search/wd/%E7%83%AD%E9%97%A8%E6%A0%87%E7%AD%BE2">热门标签2</a>');
document.write('<a href="/gxcms/index.php?s=video/search/wd/%E7%83%AD%E9%97%A8%E6%A0%87%E7%AD%BE3">热门标签3</a>');
document.write('<a href="/gxcms/index.php?s=video/search/wd/%E7%83%AD%E9%97%A8%E6%A0%87%E7%AD%BE4">热门标签4</a>');
